---
name: Teste de troca / regressão
about: Registrar resultado reproduzível de teste em emulador
---

## Versão / ambiente
- Emulador e versão:
- ROM (região e CRC-32, não anexar a ROM):
- Commit do projeto:

## Cenário
- Jogador: P1 / P2
- Personagem antes:
- Personagem depois:
- Estado (parado, atacando, recebendo golpe, etc.):

## Resultado esperado

## Resultado observado

## Evidências
Não anexar ROM, patches comerciais, músicas ou outros assets protegidos. Capturas de RAM apenas se necessárias e sem dados pessoais.
